package com.example.recept_pwa2;

import org.springframework.boot.SpringApplication;

public class TestReceptPwa2Application {

	public static void main(String[] args) {
		SpringApplication.from(ReceptPwa2Application::main).with(TestcontainersConfiguration.class).run(args);
	}

}
